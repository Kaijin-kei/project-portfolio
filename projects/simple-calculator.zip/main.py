while True:
    number_one = int(input("number 1: "))
    number_two = int(input("number 2: "))
    operation = input("operation: ")
    
    if operation == "+":
        print('number_one' + 'number_two')
        
        